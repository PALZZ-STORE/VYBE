# VYBE — Android music player starter

VYBE is an Android-native starter project for Android 6+ with a Light Liquid Glass-inspired UI. It targets Android 13 devices such as Vivo Y20s [g].

## Current MVP
- Scan and play local audio files using Android MediaStore / MediaPlayer.
- Search and stream internet radio stations via Radio Browser API.
- Favorite tracks and a basic most-played list saved on-device.
- Lyrics lookup via LRCLIB when a matching entry is available.
- No ads SDK included.
- GitHub Actions workflow builds a debug APK.

## Important limits in this starter
- The “most played” list currently records tracks played, not a full ranked play-count history.
- Lyrics are fetched when available; synchronization/word-by-word timing is not implemented yet.
- Local audio files work offline. Stream downloads and a dedicated media cache manager are not implemented.
- Online catalog is legal internet radio streams, not a full commercial Spotify-style licensed song catalog. Add licensed APIs/providers only after reviewing their terms and obtaining any required keys/permissions.
- Background playback/media notification, playlists beyond favorites, album art extraction, queue, and polished accessibility need follow-up work.

## Build APK from a phone (GitHub Actions)
1. Create a GitHub repository named `VYBE`.
2. Upload all files in this project to the repository root (keep `.github/workflows/build-apk.yml`).
3. Open the repository on GitHub → **Actions** → **Build VYBE APK** → **Run workflow**.
4. When it finishes, open the workflow run and download **VYBE-debug-apk** from Artifacts.
5. Extract the ZIP and install `app-debug.apk` on the phone. If Android asks, allow your browser/file manager to install unknown apps.

## Local build
Requires JDK 17 and Gradle 8.9. Run `gradle assembleDebug`; APK output is `app/build/outputs/apk/debug/app-debug.apk`.
