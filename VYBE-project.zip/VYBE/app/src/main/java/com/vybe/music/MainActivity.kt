package com.vybe.music

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Track(val id: String, val title: String, val artist: String, val uri: Uri, val radio: Boolean = false)
private val Ink = Color(0xFF202137)
private val Muted = Color(0xFF85869B)
private val Violet = Color(0xFF7775F8)
private val Canvas = Color(0xFFF7F8FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VybeApp() }
    }
}

@Composable
fun VybeApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("vybe_data", 0) }
    var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var stations by remember { mutableStateOf(emptyList<Track>()) }
    var tab by remember { mutableStateOf("Home") }
    var search by remember { mutableStateOf("") }
    var current by remember { mutableStateOf<Track?>(null) }
    var playing by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Scan musik lokal buat mulai") }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()) }
    var top by remember { mutableStateOf(prefs.getStringSet("top", emptySet())?.toSet() ?: emptySet()) }
    var lyrics by remember { mutableStateOf("Pilih lagu untuk mencari lirik…") }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var permissionGranted by remember { mutableStateOf(false) }

    fun scanMusic() {
        val found = mutableListOf<Track>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        context.contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                found.add(Track("local:$id", c.getString(titleCol) ?: "Unknown track", c.getString(artistCol) ?: "Unknown artist", ContentUris.withAppendedId(collection, id)))
            }
        }
        tracks = found
        message = if (found.isEmpty()) "Belum ada file musik di HP" else "${found.size} lagu ditemukan"
    }
    fun play(track: Track) {
        try {
            player?.release()
            player = MediaPlayer().apply {
                if (track.radio) setDataSource(track.uri.toString()) else setDataSource(context, track.uri)
                setOnPreparedListener { it.start(); playing = true }
                setOnCompletionListener { playing = false }
                setOnErrorListener { _, _, _ -> playing = false; message = "Gagal memutar. Coba sumber lain."; true }
                prepareAsync()
            }
            current = track
            top = (top + track.id).toSet()
            prefs.edit().putStringSet("top", top).apply()
            lyrics = "Mencari lirik…"
            scope.launch {
                lyrics = withContext(Dispatchers.IO) { fetchLyrics(track.title, track.artist) }
            }
        } catch (_: Exception) { message = "File nggak bisa diputar." }
    }
    fun searchRadio(query: String) {
        scope.launch {
            message = "Mencari radio…"
            stations = withContext(Dispatchers.IO) { fetchStations(query) }
            message = if (stations.isEmpty()) "Radio nggak ketemu. Coba kata lain." else "${stations.size} radio ditemukan"
        }
    }
    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionGranted = granted
        if (granted) scanMusic() else message = "Izin musik dibutuhkan buat scan file lokal."
    }
    LaunchedEffect(Unit) {
        permissionGranted = ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
        if (permissionGranted) scanMusic()
    }
    MaterialTheme(colorScheme = lightColorScheme(primary = Violet, background = Canvas, surface = Color.White)) {
        Scaffold(containerColor = Canvas, bottomBar = {
            Column {
                if (current != null) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp).clip(RoundedCornerShape(20.dp)).background(Brush.horizontalGradient(listOf(Color(0xFFF0EFFF), Color(0xFFF1FAFF), Color.White))).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFDCD9FF)), contentAlignment = Alignment.Center) { Icon(Icons.Filled.MusicNote, null, tint = Violet) }
                        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) { Text(current!!.title, color = Ink, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(current!!.artist, color = Muted, fontSize = 11.sp, maxLines = 1) }
                        IconButton(onClick = { if (playing) { player?.pause(); playing = false } else { player?.start(); playing = true } }) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = Violet) }
                        IconButton(onClick = { player?.stop(); player?.release(); player = null; current = null; playing = false }) { Icon(Icons.Filled.Close, null, tint = Muted) }
                    }
                }
            NavigationBar(containerColor = Color.White.copy(alpha = .94f), tonalElevation = 0.dp) {
                listOf("Home" to Icons.Filled.Home, "Search" to Icons.Filled.Search, "Library" to Icons.Filled.LibraryMusic).forEach { (label, icon) ->
                    NavigationBarItem(selected = tab == label, onClick = { tab = label }, icon = { Icon(icon, null) }, label = { Text(label) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Violet, selectedTextColor = Violet, indicatorColor = Color(0xFFECEBFF)))
                }
            }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("VYBE", fontSize = 28.sp, fontWeight = FontWeight.Black, color = Ink, letterSpacing = 2.sp)
                        Text("your sound, your space", fontSize = 12.sp, color = Muted)
                    }
                    Box(Modifier.size(42.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFFD9D7FF), Color(0xFFE9F8FF)))), contentAlignment = Alignment.Center) { Icon(Icons.Filled.GraphicEq, null, tint = Violet) }
                }
                when (tab) {
                    "Home" -> LazyColumn(contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        item {
                            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Color(0xFFE3E1FF), Color(0xFFEAF7FF), Color.White))).padding(22.dp)) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("A LITTLE LESS NOISE.", color = Violet, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                                    Text("Feel every\nfrequency.", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Bold, lineHeight = 34.sp)
                                    Text("Musik lokal + radio internet legal", color = Muted, fontSize = 13.sp)
                                    Button(onClick = { if (permissionGranted) scanMusic() else permissionLauncher.launch(permission) }, shape = RoundedCornerShape(14.dp)) { Icon(Icons.Filled.LibraryMusic, null, Modifier.size(17.dp)); Spacer(Modifier.width(7.dp)); Text("Scan musik HP") }
                                }
                            }
                        }
                        item { SectionTitle("Recently in your orbit", "${tracks.size} lagu lokal") }
                        if (tracks.isEmpty()) item { EmptyCard(message, "Izinkan akses audio atau tambahkan file musik ke HP.") }
                        items(tracks.take(12), key = { it.id }) { track -> TrackRow(track, current?.id == track.id, favorites.contains(track.id), { play(track) }, { toggleFavorite(track, favorites, prefs) { favorites = it } }) }
                        item { SectionTitle("Legal radio", "Streaming gratis") }
                        item { OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Cari radio, mis. jazz / indie") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, trailingIcon = { IconButton(onClick = { searchRadio(search) }) { Icon(Icons.Filled.ArrowForward, "Cari") } }, shape = RoundedCornerShape(18.dp), singleLine = true) }
                        items(stations.take(10), key = { it.id }) { track -> TrackRow(track, current?.id == track.id, favorites.contains(track.id), { play(track) }, { toggleFavorite(track, favorites, prefs) { favorites = it } }) }
                    }
                    "Search" -> Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                        Text("Find your frequency", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Lagu lokal atau radio online") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, trailingIcon = { IconButton(onClick = { searchRadio(search) }) { Icon(Icons.Filled.Search, "Cari radio") } }, shape = RoundedCornerShape(18.dp), singleLine = true)
                        Spacer(Modifier.height(14.dp))
                        Text("MUSIK LOKAL", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        LazyColumn { items(tracks.filter { it.title.contains(search, true) || it.artist.contains(search, true) }, key = { it.id }) { t -> TrackRow(t, current?.id == t.id, favorites.contains(t.id), { play(t) }, { toggleFavorite(t, favorites, prefs) { favorites = it } }) } }
                        Spacer(Modifier.height(8.dp)); Text(message, color = Muted, fontSize = 12.sp)
                    }
                    else -> LazyColumn(contentPadding = PaddingValues(horizontal = 18.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item { Text("Your library", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink); Text("Semua yang kamu simpan, satu tempat.", color = Muted, fontSize = 13.sp) }
                        item { LibraryTile("♡", "Liked songs", "${favorites.size} lagu", Color(0xFFE8E6FF)) }
                        items(tracks.filter { favorites.contains(it.id) }, key = { "fav-${it.id}" }) { t -> TrackRow(t, current?.id == t.id, true, { play(t) }, { toggleFavorite(t, favorites, prefs) { favorites = it } }) }
                        item { LibraryTile("↗", "Most played", "${top.size} lagu pernah diputar", Color(0xFFE0F5F0)) }
                        items(tracks.filter { top.contains(it.id) }.sortedBy { it.title }, key = { "top-${it.id}" }) { t -> TrackRow(t, current?.id == t.id, favorites.contains(t.id), { play(t) }, { toggleFavorite(t, favorites, prefs) { favorites = it } }) }
                        item { LibraryTile("↓", "Offline & cache", "File lokal bisa diputar offline", Color(0xFFFFEEDC)) }
                        item { LibraryTile("♫", "Lyrics", "${current?.title ?: "Pilih lagu"}", Color(0xFFE9F1FF)) }
                        item { Text(lyrics, color = Muted, fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White).padding(16.dp)) }
                    }
                }
            }
        }
    }
}

@Composable private fun SectionTitle(title: String, detail: String) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(title, Modifier.weight(1f), color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold); Text(detail, color = Muted, fontSize = 11.sp) } }
@Composable private fun EmptyCard(title: String, subtitle: String) { Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White).padding(18.dp)) { Text(title, color = Ink, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 12.sp) } }
@Composable private fun LibraryTile(icon: String, title: String, subtitle: String, tint: Color) { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White).padding(13.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(tint), contentAlignment = Alignment.Center) { Text(icon, fontSize = 24.sp, color = Ink, fontWeight = FontWeight.Bold) }; Column(Modifier.padding(start = 12.dp)) { Text(title, color = Ink, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 12.sp) } } }
@Composable private fun TrackRow(track: Track, active: Boolean, favorite: Boolean, onPlay: () -> Unit, onFavorite: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(if (active) Color(0xFFEDEBFF) else Color.White).clickable { onPlay() }.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Color(0xFFE2DFFF), Color(0xFFE3F7F5)))), contentAlignment = Alignment.Center) { Icon(if (track.radio) Icons.Filled.Radio else Icons.Filled.MusicNote, null, tint = Violet) }
        Column(Modifier.weight(1f).padding(horizontal = 11.dp)) { Text(track.title, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(track.artist, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
        IconButton(onClick = onFavorite, modifier = Modifier.size(34.dp)) { Icon(if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, tint = if (favorite) Violet else Muted, modifier = Modifier.size(19.dp)) }
        Icon(Icons.Filled.PlayArrow, null, tint = if (active) Violet else Muted)
    }
}
private fun toggleFavorite(track: Track, current: Set<String>, prefs: android.content.SharedPreferences, update: (Set<String>) -> Unit) { val next = if (current.contains(track.id)) current - track.id else current + track.id; prefs.edit().putStringSet("favorites", next).apply(); update(next) }
private fun fetchStations(query: String): List<Track> {
    if (query.isBlank()) return emptyList()
    return try {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val conn = (URL("https://de1.api.radio-browser.info/json/stations/search?name=$encoded&limit=15&hidebroken=true").openConnection() as HttpURLConnection).apply { connectTimeout = 8000; readTimeout = 8000; setRequestProperty("User-Agent", "VYBE/0.1 Android Music Player") }
        val json = JSONArray(conn.inputStream.bufferedReader().use { it.readText() }); conn.disconnect()
        (0 until json.length()).mapNotNull { i -> val o = json.optJSONObject(i) ?: return@mapNotNull null; val stream = o.optString("url_resolved", o.optString("url")); if (!stream.startsWith("http")) null else Track("radio:${o.optString("stationuuid", i.toString())}", o.optString("name", "Internet Radio"), o.optString("country", "Live radio"), Uri.parse(stream), true) }
    } catch (_: Exception) { emptyList() }
}
private fun fetchLyrics(title: String, artist: String): String {
    return try {
        val t = URLEncoder.encode(title, "UTF-8"); val a = URLEncoder.encode(artist, "UTF-8")
        val conn = (URL("https://lrclib.net/api/get?track_name=$t&artist_name=$a").openConnection() as HttpURLConnection).apply { connectTimeout = 7000; readTimeout = 7000; setRequestProperty("User-Agent", "VYBE/0.1") }
        val body = conn.inputStream.bufferedReader().use { it.readText() }; conn.disconnect()
        val o = org.json.JSONObject(body); val plain = o.optString("plainLyrics", ""); if (plain.isBlank()) "Lirik belum tersedia untuk lagu ini." else plain
    } catch (_: Exception) { "Lirik belum tersedia atau koneksi lagi bermasalah." }
}
