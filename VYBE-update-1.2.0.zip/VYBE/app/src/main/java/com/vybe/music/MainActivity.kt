package com.vybe.music

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Track(val id: String, val title: String, val artist: String, val uri: Uri)
private val Violet = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF43D9F5)
private val WhiteText = Color(0xFFF7F5FF)
private val SoftText = Color(0xFFB7B6C9)
private val GlassBorder = Color.White.copy(alpha = .17f)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { VybeApp() } }
}

@Composable
private fun VybeApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("vybe_data", 0) }
    val scope = rememberCoroutineScope()
    var signedIn by remember { mutableStateOf(prefs.getBoolean("signed_in", false)) }
    var userName by remember { mutableStateOf(prefs.getString("user_name", "") ?: "") }
    var email by remember { mutableStateOf(prefs.getString("email", "") ?: "") }
    var loginName by remember { mutableStateOf("") }
    var loginEmail by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf("Home") }
    var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var query by remember { mutableStateOf("") }
    var current by remember { mutableStateOf<Track?>(null) }
    var playing by remember { mutableStateOf(false) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var message by remember { mutableStateOf("Pindai musik di HP untuk mulai mendengarkan.") }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()) }
    var played by remember { mutableStateOf(prefs.getStringSet("played", emptySet())?.toSet() ?: emptySet()) }
    var lyrics by remember { mutableStateOf("Pilih lagu untuk melihat lirik yang tersedia.") }
    var glass by remember { mutableFloatStateOf(prefs.getFloat("glass", .20f)) }
    var accent by remember { mutableIntStateOf(prefs.getInt("accent", 0)) }
    var customTitle by remember { mutableStateOf(prefs.getString("app_title", "VYBE") ?: "VYBE") }
    val accentColor = when (accent) { 1 -> Color(0xFF25C9B8); 2 -> Color(0xFFFF8C69); 3 -> Color(0xFF72A7FF); else -> Violet }
    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    fun scanMusic() {
        val found = mutableListOf<Track>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
        context.contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID); val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE); val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (c.moveToNext()) { val id = c.getLong(idCol); found.add(Track("local:$id", c.getString(titleCol) ?: "Lagu tanpa judul", c.getString(artistCol) ?: "Artis tidak diketahui", ContentUris.withAppendedId(collection, id))) }
        }
        tracks = found; message = if (found.isEmpty()) "Belum ada lagu lokal yang ditemukan. Simpan file musik di HP lalu pindai lagi." else "${found.size} lagu siap diputar"
    }
    fun play(track: Track) {
        try {
            player?.release(); player = MediaPlayer().apply { setDataSource(context, track.uri); setOnPreparedListener { it.start(); playing = true }; setOnCompletionListener { playing = false }; setOnErrorListener { _, _, _ -> playing = false; message = "Lagu tidak dapat diputar."; true }; prepareAsync() }
            current = track; played = (played + track.id).toSet(); prefs.edit().putStringSet("played", played).apply(); lyrics = "Mencari lirik…"
            scope.launch { lyrics = withContext(Dispatchers.IO) { fetchLyrics(track.title, track.artist) } }
        } catch (_: Exception) { message = "File lagu tidak dapat dibuka." }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) scanMusic() else message = "Izin audio diperlukan untuk membaca musik di HP." }
    LaunchedEffect(Unit) { if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) scanMusic() }

    MaterialTheme(colorScheme = darkColorScheme(primary = accentColor, secondary = Cyan, background = Color(0xFF08080D), surface = Color(0xFF15141E), onBackground = WhiteText, onSurface = WhiteText)) {
        if (!signedIn) {
            LoginScreen(loginName, { loginName = it }, loginEmail, { loginEmail = it }, accentColor) {
                userName = loginName.trim().ifBlank { loginEmail.substringBefore('@').ifBlank { "Listener" } }
                email = loginEmail.trim(); signedIn = true
                prefs.edit().putBoolean("signed_in", true).putString("user_name", userName).putString("email", email).apply()
            }
        } else {
            Scaffold(containerColor = Color(0xFF08080D), bottomBar = {
                Column {
                    current?.let { track ->
                        GlassPanel(glass, Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp)) {
                            Row(Modifier.fillMaxWidth().clickable { tab = "Player" }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                AlbumTile(Modifier.size(43.dp), accentColor)
                                Column(Modifier.weight(1f).padding(horizontal = 10.dp)) { Text(track.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(track.artist, color = SoftText, fontSize = 11.sp, maxLines = 1) }
                                IconButton(onClick = { if (playing) { player?.pause(); playing = false } else { player?.start(); playing = true } }) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = accentColor) }
                                IconButton(onClick = { player?.release(); player = null; current = null; playing = false }) { Icon(Icons.Filled.Close, null, tint = SoftText) }
                            }
                        }
                    }
                    NavigationBar(containerColor = Color(0xEE111019), tonalElevation = 0.dp) {
                        listOf("Home" to Icons.Filled.Home, "Search" to Icons.Filled.Search, "Library" to Icons.Filled.LibraryMusic, "Settings" to Icons.Filled.Tune).forEach { (label, icon) ->
                            NavigationBarItem(selected = tab == label, onClick = { tab = label }, icon = { Icon(icon, null) }, label = { Text(label, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = accentColor, selectedTextColor = accentColor, unselectedIconColor = SoftText, unselectedTextColor = SoftText, indicatorColor = accentColor.copy(alpha = .18f)))
                        }
                    }
                }
            }) { padding ->
                Column(Modifier.fillMaxSize().padding(padding).background(Brush.verticalGradient(listOf(Color(0xFF171329), Color(0xFF09090F), Color(0xFF07070B))))) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.vybe_logo), contentDescription = "Logo VYBE", modifier = Modifier.size(44.dp))
                        Column(Modifier.weight(1f).padding(start = 9.dp)) { Text(customTitle, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp); Text("YOUR SOUND. YOUR SPACE.", fontSize = 9.sp, color = SoftText, letterSpacing = 1.5.sp) }
                        IconButton(onClick = { tab = "About" }) { Icon(Icons.Filled.Info, "Info aplikasi", tint = SoftText) }
                    }
                    when (tab) {
                        "Home" -> LazyColumn(contentPadding = PaddingValues(horizontal = 17.dp, vertical = 5.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            item { GlassPanel(glass, Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp)) {
                                Text("YOUR MUSIC. YOUR MOMENT.", color = accentColor, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
                                Text("Put your world\non repeat.", fontSize = 31.sp, lineHeight = 35.sp, fontWeight = FontWeight.ExtraBold)
                                Text("Musik dari HP kamu, tanpa radio dan tanpa iklan di aplikasi.", color = SoftText, fontSize = 12.sp)
                                Spacer(Modifier.height(10.dp)); Button(onClick = { if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) scanMusic() else permissionLauncher.launch(permission) }, colors = ButtonDefaults.buttonColors(containerColor = accentColor), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Filled.LibraryMusic, null); Spacer(Modifier.width(7.dp)); Text("Pindai musik HP") }
                            } } }
                            item { SectionHeader("Recently played", "${played.size} lagu") }
                            if (tracks.isEmpty()) item { GlassPanel(glass, Modifier.fillMaxWidth()) { Column(Modifier.padding(17.dp)) { Text(message, color = SoftText); Text("File MP3, M4A, FLAC, dan format yang didukung Android akan muncul di sini.", color = SoftText, fontSize = 12.sp) } } }
                            items(tracks.take(15), key = { it.id }) { t -> TrackRow(t, current?.id == t.id, favorites.contains(t.id), accentColor, { play(t) }, { val n = if (favorites.contains(t.id)) favorites - t.id else favorites + t.id; favorites = n; prefs.edit().putStringSet("favorites", n).apply() }) }
                        }
                        "Search" -> Column(Modifier.fillMaxSize().padding(horizontal = 17.dp)) {
                            Text("Cari di koleksi", fontSize = 24.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp))
                            OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Judul lagu atau nama artis") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, shape = RoundedCornerShape(18.dp), singleLine = true, colors = glassFieldColors())
                            Spacer(Modifier.height(12.dp)); LazyColumn { items(tracks.filter { it.title.contains(query, true) || it.artist.contains(query, true) }, key = { it.id }) { t -> TrackRow(t, current?.id == t.id, favorites.contains(t.id), accentColor, { play(t) }, { val n = if (favorites.contains(t.id)) favorites - t.id else favorites + t.id; favorites = n; prefs.edit().putStringSet("favorites", n).apply() }) } }
                        }
                        "Library" -> LazyColumn(contentPadding = PaddingValues(horizontal = 17.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            item { Text("Your Library", fontSize = 27.sp, fontWeight = FontWeight.Bold); Text("Koleksi musikmu dalam satu tempat.", color = SoftText, fontSize = 12.sp) }
                            item { LibraryCard("♥", "Liked songs", "${favorites.size} lagu favorit", accentColor, glass) }
                            items(tracks.filter { favorites.contains(it.id) }, key = { "fav-${it.id}" }) { t -> TrackRow(t, current?.id == t.id, true, accentColor, { play(t) }, { favorites = favorites - t.id; prefs.edit().putStringSet("favorites", favorites).apply() }) }
                            item { LibraryCard("♫", "Most played", "${played.size} lagu pernah diputar", Cyan, glass) }
                            items(tracks.filter { played.contains(it.id) }, key = { "played-${it.id}" }) { t -> TrackRow(t, current?.id == t.id, favorites.contains(t.id), accentColor, { play(t) }, { val n = if (favorites.contains(t.id)) favorites - t.id else favorites + t.id; favorites = n; prefs.edit().putStringSet("favorites", n).apply() }) }
                            item { LibraryCard("♪", "Lirik", current?.title ?: "Pilih lagu untuk mencari lirik", Color(0xFFFEA86B), glass) }
                            item { GlassPanel(glass, Modifier.fillMaxWidth()) { Text(lyrics, Modifier.padding(16.dp), color = SoftText, fontSize = 13.sp, lineHeight = 20.sp) } }
                            item { OutlinedButton(onClick = { if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) scanMusic() else permissionLauncher.launch(permission) }) { Icon(Icons.Filled.Refresh, null); Spacer(Modifier.width(7.dp)); Text("Pindai ulang musik") } }
                        }
                        "Settings" -> LazyColumn(contentPadding = PaddingValues(horizontal = 17.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                            item { Text("Personalisasi", fontSize = 27.sp, fontWeight = FontWeight.Bold); Text("Atur tampilan VYBE sesuai seleramu.", color = SoftText, fontSize = 12.sp) }
                            item { GlassPanel(glass, Modifier.fillMaxWidth()) { Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("LIQUID GLASS", color = accentColor, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                                Text("Intensitas transparansi · ${(glass * 100).toInt()}%", fontWeight = FontWeight.SemiBold)
                                Slider(value = glass, onValueChange = { glass = it }, valueRange = .08f.. .42f, onValueChangeFinished = { prefs.edit().putFloat("glass", glass).apply() }, colors = SliderDefaults.colors(thumbColor = accentColor, activeTrackColor = accentColor))
                                Text("Warna aksen", fontWeight = FontWeight.SemiBold)
                                Row(horizontalArrangement = Arrangement.spacedBy(13.dp)) { listOf(Violet, Color(0xFF25C9B8), Color(0xFFFF8C69), Color(0xFF72A7FF)).forEachIndexed { i, c -> Box(Modifier.size(37.dp).clip(CircleShape).background(c).border(if (accent == i) 3.dp else 0.dp, Color.White, CircleShape).clickable { accent = i; prefs.edit().putInt("accent", i).apply() }) } }
                                OutlinedTextField(value = customTitle, onValueChange = { customTitle = it; prefs.edit().putString("app_title", it).apply() }, label = { Text("Nama tampilan") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = glassFieldColors())
                            } } }
                            item { GlassPanel(glass, Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("AKUN", color = accentColor, fontSize = 11.sp, fontWeight = FontWeight.Bold); Text(userName, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text(email, color = SoftText, fontSize = 12.sp); Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = { signedIn = false; prefs.edit().putBoolean("signed_in", false).apply() }) { Icon(Icons.Filled.Logout, null); Spacer(Modifier.width(7.dp)); Text("Keluar") } } } }
                            item { GlassPanel(glass, Modifier.fillMaxWidth().clickable { tab = "About" }) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.Info, null, tint = accentColor); Column(Modifier.weight(1f).padding(start = 12.dp)) { Text("Info aplikasi & pembaruan", fontWeight = FontWeight.SemiBold); Text("Versi, changelog, dan informasi VYBE", color = SoftText, fontSize = 12.sp) }; Icon(Icons.Filled.ChevronRight, null, tint = SoftText) } } }
                        }
                        "Player" -> current?.let { t -> Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Image(painterResource(R.drawable.vybe_logo), contentDescription = "Logo VYBE", modifier = Modifier.size(185.dp))
                            Spacer(Modifier.height(20.dp)); Text(t.title, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis); Text(t.artist, color = SoftText)
                            Spacer(Modifier.height(18.dp)); Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = { if (favorites.contains(t.id)) favorites = favorites - t.id else favorites = favorites + t.id; prefs.edit().putStringSet("favorites", favorites).apply() }) { Icon(if (favorites.contains(t.id)) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, tint = accentColor) }; IconButton(onClick = { if (playing) { player?.pause(); playing = false } else { player?.start(); playing = true } }, modifier = Modifier.size(70.dp).clip(CircleShape).background(accentColor)) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = Color.White, modifier = Modifier.size(36.dp)) } }
                            Spacer(Modifier.height(20.dp)); GlassPanel(glass, Modifier.fillMaxWidth()) { Text(lyrics, Modifier.padding(16.dp), color = SoftText, fontSize = 13.sp, lineHeight = 20.sp) }
                        } ?: Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Pilih lagu dari Home atau Library", color = SoftText) }
                        "About" -> LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                            item { GlassPanel(glass, Modifier.fillMaxWidth()) { Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) { Image(painterResource(R.drawable.vybe_logo), null, Modifier.size(110.dp)); Text("VYBE MUSIC", fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp); Text("Your sound. Your space.", color = SoftText) } } }
                            item { InfoRow("Versi aplikasi", "1.1.0 · Music & Liquid Glass", glass) }
                            item { InfoRow("Update ini", "Pemutar musik lokal, login profil, logo VYBE, Liquid Glass yang bisa disesuaikan, favorit, riwayat, lirik, dan halaman pengaturan.", glass) }
                            item { InfoRow("Sumber musik", "Memutar file musik yang tersedia di perangkat. VYBE tidak menyertakan katalog Spotify atau streaming lagu berhak cipta tanpa izin.", glass) }
                            item { InfoRow("Status pembaruan", "Versi ini adalah build pengembangan. Pembaruan otomatis belum terhubung ke server; cek rilis terbaru dari pengembang.", glass) }
                            item { OutlinedButton(onClick = { tab = "Settings" }) { Icon(Icons.Filled.Settings, null); Spacer(Modifier.width(7.dp)); Text("Pengaturan tampilan") } }
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun LoginScreen(name: String, onName: (String) -> Unit, email: String, onEmail: (String) -> Unit, accent: Color, onContinue: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF20133C), Color(0xFF090910), Color(0xFF06060A)))).padding(24.dp), contentAlignment = Alignment.Center) {
        GlassPanel(.24f, Modifier.fillMaxWidth()) { Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.vybe_logo), "Logo VYBE", Modifier.size(100.dp)); Text("Welcome to VYBE", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold); Text("Masuk untuk menyimpan profil dan preferensi di perangkat ini.", color = SoftText, fontSize = 12.sp)
            OutlinedTextField(value = name, onValueChange = onName, modifier = Modifier.fillMaxWidth(), label = { Text("Nama tampilan") }, singleLine = true, colors = glassFieldColors())
            OutlinedTextField(value = email, onValueChange = onEmail, modifier = Modifier.fillMaxWidth(), label = { Text("Email (opsional)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), colors = glassFieldColors())
            Button(onClick = onContinue, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = accent), shape = RoundedCornerShape(15.dp)) { Text("Lanjutkan") }
            Text("Catatan: login ini menyimpan profil secara lokal. Akun online dan sinkronisasi cloud belum tersedia.", color = SoftText, fontSize = 10.sp)
        } }
    }
}

@Composable private fun GlassPanel(intensity: Float, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.clip(RoundedCornerShape(25.dp)).background(Brush.linearGradient(listOf(Color(0xFFB5A9FF).copy(alpha = intensity), Color.White.copy(alpha = intensity * .55f), Color(0xFF3FD7F2).copy(alpha = intensity * .40f)))).border(1.dp, GlassBorder, RoundedCornerShape(25.dp)), content = content)
}
@Composable private fun AlbumTile(modifier: Modifier, accent: Color) { Box(modifier.clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(accent.copy(alpha = .75f), Cyan.copy(alpha = .6f)))), contentAlignment = Alignment.Center) { Icon(Icons.Filled.GraphicEq, null, tint = Color.White, modifier = Modifier.size(25.dp)) } }
@Composable private fun SectionHeader(title: String, subtitle: String) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(title, Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 17.sp); Text(subtitle, color = SoftText, fontSize = 11.sp) } }
@Composable private fun TrackRow(track: Track, active: Boolean, favorite: Boolean, accent: Color, onPlay: () -> Unit, onFavorite: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(if (active) accent.copy(alpha = .18f) else Color.White.copy(alpha = .055f)).border(1.dp, if (active) accent.copy(alpha = .4f) else GlassBorder, RoundedCornerShape(18.dp)).clickable { onPlay() }.padding(horizontal = 11.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        AlbumTile(Modifier.size(46.dp), accent)
        Column(Modifier.weight(1f).padding(horizontal = 11.dp)) { Text(track.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(track.artist, color = SoftText, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
        IconButton(onClick = onFavorite, modifier = Modifier.size(35.dp)) { Icon(if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, tint = if (favorite) accent else SoftText, modifier = Modifier.size(19.dp)) }
        Icon(Icons.Filled.PlayArrow, null, tint = accent)
    }
}
@Composable private fun LibraryCard(icon: String, title: String, subtitle: String, accent: Color, glass: Float) { GlassPanel(glass, Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(45.dp).clip(RoundedCornerShape(14.dp)).background(accent.copy(alpha = .22f)), contentAlignment = Alignment.Center) { Text(icon, color = accent, fontSize = 25.sp, fontWeight = FontWeight.Bold) }; Column(Modifier.weight(1f).padding(start = 12.dp)) { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, color = SoftText, fontSize = 12.sp) } } } }
@Composable private fun InfoRow(title: String, detail: String, glass: Float) { GlassPanel(glass, Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text(title, fontWeight = FontWeight.Bold); Spacer(Modifier.height(4.dp)); Text(detail, color = SoftText, fontSize = 12.sp, lineHeight = 18.sp) } } }
@Composable private fun glassFieldColors() = OutlinedTextFieldDefaults.colors(focusedBorderColor = Violet, unfocusedBorderColor = GlassBorder, focusedLabelColor = Violet, unfocusedLabelColor = SoftText, focusedTextColor = WhiteText, unfocusedTextColor = WhiteText, cursorColor = Violet)
private fun fetchLyrics(title: String, artist: String): String = try {
    val t = URLEncoder.encode(title, "UTF-8"); val a = URLEncoder.encode(artist, "UTF-8")
    val conn = (URL("https://lrclib.net/api/get?track_name=$t&artist_name=$a").openConnection() as HttpURLConnection).apply { connectTimeout = 7000; readTimeout = 7000; setRequestProperty("User-Agent", "VYBE/1.1 Android Music Player") }
    val body = conn.inputStream.bufferedReader().use { it.readText() }; conn.disconnect(); val obj = JSONObject(body); val text = obj.optString("plainLyrics", ""); if (text.isBlank()) "Lirik belum tersedia untuk lagu ini." else text
} catch (_: Exception) { "Lirik belum tersedia atau koneksi internet bermasalah." }
