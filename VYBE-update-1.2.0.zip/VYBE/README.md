# VYBE Music 1.2.0

VYBE is an Android local-music player prototype built with Kotlin and Jetpack Compose, styled with a dark Liquid Glass-inspired interface.

## Included in this build
- Local device music scanning and playback (Android MediaStore)
- Search across local song titles and artists
- Liked songs and a most-played list saved locally
- Lyrics lookup through LRCLIB when a match and internet connection are available
- Local profile/login screen (not a cloud account system)
- Customizable glass intensity, accent color, and app display title
- App info/version/changelog screen
- VYBE launcher icon configured for Android adaptive icons and older Android versions

## Important limitations
- No Spotify catalogue or Spotify account integration.
- Online account authentication, cloud sync, automatic updates, and downloaded online music are not implemented.
- The login/profile is stored on this device only.
- Lyrics depend on availability from the external LRCLIB service.
- This is a development/debug build, not a signed production release.

## Build
Open this project in Android Studio with JDK 17 and Gradle 8.9, then run `gradle assembleDebug` from the `VYBE` project directory.


## Update 1.2.0
- Bumped Android version to 1.2.0 (versionCode 3).
- Added adaptive and legacy launcher icon resources so the downloaded/installed APK has a VYBE app icon instead of a blank/default icon.
- This update does not add a licensed online music catalogue; playback remains limited to audio available on the device.
